
void book_clear(void);
void book_open(const char file_name[]);
void book_close(void);
bool book_find_move(PCON pcon, CM *cm, bool random);
void book_disp(PCON pcon, PSTE pste);

